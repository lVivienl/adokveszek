<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="feltoltes.css">
    <title>Marketplace - Termékfeltöltés</title>
</head>
<body>
    <div class="feltoltesfejlec">
        <h2>Termékfeltöltés</h2>
    </div>
<div id="betu">
        <form action="feltoltes_ir.php" method="POST" enctype="multipart/form-data" id="feltoltesform" target='kisablak'>
            <label for="product_name">Termék neve:</label>
            <input type="text" id="product_name" name="product_name" required>

            <label for="description">Leírás:</label>
            <textarea id="description" name="description" rows="5" required></textarea>

            <label for="price">Ár (HUF):</label>
            <input type="number" id="price" name="price" step="5" min="0" required>

            <label for="category">Kategória:</label>
            <select id="category" name="category" required>
                <option value="">Válassz kategóriát</option>
                <option value="elektronika">Elektronika</option>
                <option value="ruhazat">Ruházat</option>
                <option value="haztartas">Háztartás</option>
                <option value="egyeb">Egyéb</option>
            </select>
            <label for="condition">Termék állapota:</label>
            <select id="condition" name="condition" required>
                    <option value="">Válaszd ki a termék állapotát</option>
                    <option value="uj">Új</option>
                    <option value="ujszeru">Újszerű</option>
                    <option value="hasznalt">Használt</option>
            </select>
            <!-- <div class="product-condition">
                <label><input type="radio" name="condition" value="új"> Új</label>
                <label><input type="radio" name="condition" value="újszerű"> Újszerű</label>
                <label><input type="radio" name="condition" value="használt"> Használt</label>   
            </div> -->

            <label for="image">Termék kép feltöltése:</label>
            <input type="file" id="image" name="image" required>

            <input class="log" type="submit" value="Termék feltöltése">
        </form>
</div>
    <input href="adokveszek.php"class="log2" type="submit" value="Vissza a főoldalra">
</body>
</html>