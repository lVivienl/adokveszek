<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marketplace</title>
    <link rel="stylesheet" href="marketplace.css">
</head>
<body>

    
            <!-- Sidebar gomb mobil nézetben -->
            <button class="sidebar-toggle">→</button>

            <aside class="sidebar">
                <!-- Keresősáv -->
                <div class="search-bar">
                    <input type="text" placeholder="Keress termékeket...">
                </div>

                <input type="submit" value="Keresés" class="log">

                <hr class='hrhr'/>

                <!-- Ár szűrő -->
                <div class="price-filter">
                    <h3>Árkategória</h3>
                    <input type="range" id="price-range" min="0" max="50000" step="100" value="25000" oninput="updatePrice()">
                    <p>Maximum ár: <span id="price-value">25 000</span> Ft</p>
                </div>

                <!-- Kategóriák -->
                <div class="categories">
                    <label for="categories">Kategóriák</label>
                    <select id="categories" name="categories">
                        <option value="ruházat">Ruházat</option>
                        <option value="elektronika">Elektronika</option>
                        <option value="háztartás">Háztartás</option>
                        <option value="egyéb">Egyéb</option>
                    </select>
                </div>

                <!-- Termék állapota (rádiógombok) -->
                <div class="product-condition">
                    <h3>Termék állapota</h3>
                    <label><input type="radio" name="condition" value="új"> Új</label><br>
                    <label><input type="radio" name="condition" value="újszerű"> Újszerű</label><br>
                    <label><input type="radio" name="condition" value="használt"> Használt</label>
                </div>
                <hr>
                <div id="linkek">
                    <a href="kedvencek" class="gomb1">Kedvencek</a>
                    <a href="sajathirdetes" class="gomb2">Saját hirdetések</a>
                    <a href="feltoltes" class="gomb3">Termék(ek) feltöltése</a>
                </div>


            </aside>
        

        <main>
        <section id="products" class="products">
                
                <h2>Elérhető termékek</h2>
                <?php print("<div class='product-grid'>") ?>
                <?php
                    $conn = new mysqli("localhost", "root", "", "wv1" );
                    if ($conn->connect_error) {
                        die("Kapcsolódási hiba: " . $conn->connect_error);
                    }

                    $sql = "SELECT tid, tnev, tar, tkep, tuid
                            FROM termekek, user
                            WHERE tuid=uid";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<div class='product-card'>";
                            echo "<img src='./termekkepek/$row[tkep]' alt='" . $row['tnev'] . "'>";
                            echo "<div id='valami'>";
                            echo "<h3>" . $row['tnev'] . "</h3>";
                            echo "<hr>";
                            echo "<p>" . $row['tar'] . " Ft</p>";
                            echo "<div class='buttons'>
                            <button class='favorite-button' onclick='addToFavorites(1)'>
                                ♥
                            </button>
                            </div>
                            </div>";
                            echo "</div>";
                        }
                    } else {
                        echo "Nincsenek termékek.";
                    }
                    $conn->close();
                    
                 print("</div>") ?>
            </section>
        </main>


    <script>
        function updatePrice() {
            const priceRange = document.getElementById('price-range');
            const priceValue = document.getElementById('price-value');
            priceValue.textContent = priceRange.value;
        }
        document.addEventListener("DOMContentLoaded", () => {
        const sidebar = document.querySelector(".sidebar");
        const headerHeight = 100;
        
        const getOffset = () => window.innerWidth < 500 ? -3 : 7;

        window.addEventListener("scroll", () => {
            const scrollPosition = window.scrollY;
            const offset = getOffset();

            if (scrollPosition < headerHeight) {
                sidebar.style.top = `${headerHeight - scrollPosition + offset}px`;
            } else {
                sidebar.style.top = `${offset}px`;
            }
        });

        window.addEventListener("resize", () => {
            const offset = getOffset();
            sidebar.style.top = `${offset}px`;
        });
    });
    let favoriteProducts = JSON.parse(localStorage.getItem('favorites')) || [];

function addToFavorites(productId) {
    // Ellenőrizzük, hogy a termék már benne van-e a kedvencek között
    if (!favoriteProducts.includes(productId)) {
        favoriteProducts.push(productId);
        localStorage.setItem('favorites', JSON.stringify(favoriteProducts));  // Mentés a localStorage-ba
        alert('Termék a kedvencekhez adva!');
    } else {
        alert('A termék már a kedvenceid között van!');
    }
}   
    // Mobil nézetben a sidebar menü lenyitása és bezárása
    const sidebar = document.querySelector('.sidebar');
    const sidebarToggle = document.querySelector('.sidebar-toggle');

    sidebarToggle.addEventListener('click', () => {
        sidebar.classList.toggle('active'); // Sidebar megjelenítése vagy elrejtése
    });

    </script>
</body>
</html>
