<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marketplace</title>
    <link rel="stylesheet" href="marketplace.css">
</head>
<body>

    <div class="container">
        <aside class="sidebar">
        <form method="GET" action="">
    <!-- Keresősáv -->
    <div class="search-bar">
        <input type="text" name="search" placeholder="Keress termékeket..." value="<?php echo $_GET['search'] ?? ''; ?>">
        <input type="submit" value="Keresés" class="log">
    </div>

    <!-- Ár szűrő -->
    <div class="price-filter">
        <h3>Árkategória</h3>
        <input type="range" id="price-range" name="max_price" min="0" max="50000" step="100" 
               value="<?php echo $_GET['max_price'] ?? 25000; ?>" oninput="updatePrice()">
        <p>Maximum ár: <span id="price-value"><?php echo $_GET['max_price'] ?? 25000; ?></span> Ft</p>
    </div>

    <!-- Kategóriák -->
    <div class="categories">
        <label for="categories">Kategóriák</label>
        <select id="categories" name="category">
            <option value="">Összes kategória</option>
            <option value="ruházat" <?php if(($_GET['category'] ?? '') == 'ruházat') echo 'selected'; ?>>Ruházat</option>
            <option value="elektronika" <?php if(($_GET['category'] ?? '') == 'elektronika') echo 'selected'; ?>>Elektronika</option>
            <option value="háztartás" <?php if(($_GET['category'] ?? '') == 'háztartás') echo 'selected'; ?>>Háztartás</option>
            <option value="egyéb" <?php if(($_GET['category'] ?? '') == 'egyéb') echo 'selected'; ?>>Egyéb</option>
        </select>
    </div>

    <!-- Termék állapota -->
    <div class="product-condition">
        <h3>Termék állapota</h3>
        <label><input type="radio" name="condition" value="új" <?php if(($_GET['condition'] ?? '') == 'új') echo 'checked'; ?>> Új</label><br>
        <label><input type="radio" name="condition" value="újszerű" <?php if(($_GET['condition'] ?? '') == 'újszerű') echo 'checked'; ?>> Újszerű</label><br>
        <label><input type="radio" name="condition" value="használt" <?php if(($_GET['condition'] ?? '') == 'használt') echo 'checked'; ?>> Használt</label>
    </div>

    <input type="submit" value="Szűrés" class="log">
</form>

            <div id="linkek">
                <ul>
                    <li><a href="kedvencek">Kedvencek</a></li>
                    <li><a href="sajathirdetes">Saját hirdetések</a></li>
                    <li><a href="feltoltes">Termék(ek) feltöltése</a></li>
                </ul>
            </div>
        </aside>

        <main>
            <section id="products" class="products">
                
                <h2>Elérhető termékek</h2>
                <?php print("<div class='product-grid'>") ?>
                <?php
$conn = new mysqli("localhost", "root", "", "wv1");
if ($conn->connect_error) {
    die("Kapcsolódási hiba: " . $conn->connect_error);
}

// Alap SQL lekérdezés
$sql = "SELECT tid, tnev, tar, tkep, tuid, tkategoria, tallapot FROM termekek WHERE 1=1";

// Szűrők alkalmazása
if (!empty($_GET['search'])) {
    $search = $conn->real_escape_string($_GET['search']);
    $sql .= " AND tnev LIKE '%$search%'";
}

if (!empty($_GET['category'])) {
    $category = $conn->real_escape_string($_GET['category']);
    $sql .= " AND tkategoria='$category'";
}

if (!empty($_GET['condition'])) {
    $condition = $conn->real_escape_string($_GET['condition']);
    $sql .= " AND tallapot='$condition'";
}

if (!empty($_GET['max_price'])) {
    $max_price = (int)$_GET['max_price'];
    $sql .= " AND tar <= $max_price";
}

// Lekérdezés futtatása
$result = $conn->query($sql);
echo "<div class='product-grid'>";
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<div class='product-card'>";
        echo "<img src='./termekkepek/{$row['tkep']}' alt='{$row['tnev']}'>";
        echo "<h3>{$row['tnev']}</h3>";
        echo "<hr>";
        echo "<p>{$row['tar']} Ft</p>";
        echo "<form action='adokveszek_ir.php' target='kisablak' method='POST'>";
        echo "<input type='hidden' name='productId' value='{$row['tid']}'>";
        echo "<button type='submit' class='favorite-button'>♥</button>";
        echo "<a href='termek?tid=" . $row['tid'] . "' class='details-button'>Részletek megtekintése</a>";
        echo "</form>";
        echo "</div>";
    }
} else {
    echo "Nincsenek termékek a megadott szűrőkkel.";
}
echo "</div>";

$conn->close();
?>

            </section>
        </main>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
    const favoriteButtons = document.querySelectorAll('.favorite-button');

    favoriteButtons.forEach(button => {
        button.addEventListener('click', function () {
            this.classList.add('clicked');
        });
    });
});

        function updatePrice() {
            const priceRange = document.getElementById('price-range');
            const priceValue = document.getElementById('price-value');
            priceValue.textContent = priceRange.value;
        }
    </script>
</body>
</html>
