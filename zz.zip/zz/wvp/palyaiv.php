<html><head>
    <link rel="shortcut icon" href="/wmicon.ico" type="image/vnd.microsoft.icon">
    <title> WEISSes vagyok </title>

    <link href="pszihologus.css" type="text/css" rel="stylesheet">
</head>

<body>

<h1> Pályaív </h1>

<div id="szoveg">

    <p>
	Az alábbiakban korábbi weisses tanulók mesélnek az első munkatapasztalataikról, vagy éppen felsőoktatási élményeikről. 
	Olvass bele az eddigi beszámolókba, de ne feledd: a tartalom folyamatosan bővül, ezért nézz vissza később is!
    </p>
    <br>

    <a class="ivlink" href="./2021-horvath-bank/"> <img src="./img-2021-horvath-bank/2021-horvath-bank-1-s.jpg">           <h3>2021.</h3> <h1>Horváth Bánk      </h1> <h2> Programozás igen, matek nem                 </h2> </a>
    <a class="ivlink" href="./2020-dobes-dominik/"> <img src="./img-2020-dobes-dominik/dobes-dominik-1-s.jpg">              <h3>2020.</h3> <h1>Dobes Dominik     </h1> <h2> Egyetemen Észak-Írországban                 </h2> </a>
    <a class="ivlink" href="./2020-szilagyi-kristof/"> <img src="./img-2020-szilagyi-kristof/2020-szilagyi-kristof-1-s.jpg">   <h3>2020.</h3> <h1>Szilágyi Kristóf  </h1> <h2> A biztonságtechnikus, aki a börtönt figyeli </h2> </a>

    <a class="ivlink" href="./2019-koos-vilmos/"> <img src="./img-2019-koos-vilmos/koos-vilmos-1-s.jpg">
                                                        <img src="./new-icon.png" style="width:120px;">                         <h3>2019.</h3> <h1>Koós Vilmos       </h1> <h2> A kisállat-tenyésztő informatikus           </h2> </a>

    <a class="ivlink" href="./2018-orosz-adrian/"> <img src="./img-2018-orosz-adrian/orosz-adrian-1-s.jpg">                <h3>2018.</h3> <h1>Orosz Adrián      </h1> <h2> Vállalkozni, vagy nem vállalkozni?          </h2> </a>
    <a class="ivlink" href="./2016-szasz-balazs/"> <img src="./img-2016-szasz-balazs/1-tablokep-s.jpg">                    <h3>2016.</h3> <h1>Szász Balázs      </h1> <h2> Telenor után Vodafone – egyre feljebb...    </h2> </a>
    <a class="ivlink" href="./2016-varga-mihaly-mate/"> <img src="./img-2016-varga-mihaly-mate/2016-varga-mihaly-mate-1-s.jpg"> <h3>2016.</h3> <h1>Varga Mihály Máté </h1> <h2> A több lábon álló banki informatikus        </h2> </a>
    <a class="ivlink" href="./2012-lovei-daniel/"> <img src="./img-2012-lovei-daniel/2012-lovei-daniel-1-s.jpg">           <h3>2012.</h3> <h1>Lővei Dániel      </h1> <h2> A MOL informatikusai között                 </h2> </a>
    <a class="ivlink" href="./2011-harkai-david/"> <img src="./img-2011-harkai-david/harkai-david-1-s.jpg">                <h3>2011.</h3> <h1>Harkai Dávid      </h1> <h2> Tudatosan a célok felé                      </h2> </a>
    <a class="ivlink" href="./2011-szeman-roland/"> <img src="./img-2011-szeman-roland/1-portrekep-s.jpg">                  <h3>2011.</h3> <h1>Szemán Roland     </h1> <h2> A webdesigner vállalkozó                    </h2> </a>


</div>


<style>

    a.ivlink
    {
	display          : block          ;
	margin           : 24px 60px      ;
	padding          : 12px 24px      ;
	background-color : #DDE           ;
	border           : solid 2px #097 ;
	border-radius    : 6px            ;
	color            : #333           ;
	text-decoration  : none           ;
    }

    a.ivlink:hover
    {
	background-color : #EEF           ;
	border           : solid 2px #0EB ;
	text-decoration  : none!important ;
    }

    a.ivlink h1 , a.ivlink h2 , a.ivlink h3
    {
	margin           : 0              ;
	color            : #555           ;
	font-size        : 1em            ;
    }

    a.ivlink h2
    {
	font-weight      : normal         ;
    }

    a.ivlink img
    {
	float            : right          ;
	width            : 72px           ;
	border-radius    : 50%            ;
	opacity          : 75%            ;
    }
    
    a.ivlink:hover img
    {
	opacity          : 1              ;
    }




</style>

    </div>




</body></html>