<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Saját hirdetések - Marketplace</title>
    <link rel="stylesheet" href="kedvenc.css"> <!-- A CSS fájl linkelése -->
</head>
<body>

    <div class="container">
        <div class="search-bar">
            <input type="text" id="searchInput" placeholder="Keresés a saját hirdetések között..." oninput="searchAds()">
        </div>

        <div id="adGrid" class="product-grid">
            <!-- A hirdetések dinamikusan kerülnek ide -->
        </div>

        <!-- Üres állapot -->
        <div id="emptyState" class="empty-state" style="display: none;">
            <img src="ures.png" alt="No ads">
            <p>Nincsenek saját hirdetéseid. Adj fel egy új hirdetést!</p>
        </div>
    </div>
    <?php print("<div class='product-grid'>") ?>
                <?php
                    $conn = new mysqli("localhost", "root", "", "wv1" );
                    if ($conn->connect_error) {
                        die("Kapcsolódási hiba: " . $conn->connect_error);
                    }

                    $sql = "SELECT tid, tnev, tar, tkep, tuid
                            FROM termekek, user
                            WHERE tuid=uid ";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {    
                            echo "<div class='product-card'>";    
                            echo "<img src='./termekkepek/$row[tkep]' class='product-image' alt='" . $row['tnev'] . "' >";
                            echo "<h3>" . $row['tnev'] . "</h3>";
                            echo "<hr>";
                            echo "<p class='product-price'>" . $row['tar'] . " Ft</p>";
                            echo "<input type='hidden' name='productId' value='" . $row['tid'] . "'>";
                            echo "<div class='buttons'>
                                  <button onclick='removeFromFavorites($row[tid])'>Eltávolítás</button>
                                  </div>";
                            echo "</div>";
                        }
                    } else {
                        echo "Nincsenek termékek.";
                    }
                    $conn->close();
                    
                 print("</div>") ?>
    <script>
        
        // Hirdetés törlése
        function deleteAd(adId) {
            const index = ads.findIndex(ad => ad.id === adId);
            if (index !== -1) {
                ads.splice(index, 1);
                renderAds();
            }
        }

        // Hirdetés szerkesztése (jelenleg csak egy üzenetet dob fel)
        function editAd(adId) {
            alert(`A(z) ${ads.find(ad => ad.id === adId).name} hirdetés szerkesztése.`);
        }

        // Keresés a saját hirdetések között
        function searchAds() {
            const query = document.getElementById('searchInput').value.toLowerCase();
            const filteredAds = ads.filter(ad => ad.name.toLowerCase().includes(query));
            adGrid.innerHTML = '';
            filteredAds.forEach(ad => {
                const adCard = document.createElement('div');
                adCard.classList.add('product-card');

                adCard.innerHTML = `
                    <img src="${ad.image}" class="product-image" alt="${ad.name}">
                    <div class="product-details">
                        <h3>${ad.name}</h3>
                        <p class="product-price">${ad.price}</p>
                        <p>${ad.description}</p>
                        <div class="buttons">
                            <button onclick="editAd(${ad.id})">Szerkesztés</button>
                            <button onclick="deleteAd(${ad.id})">Törlés</button>
                        </div>
                    </div>
                `;
                adGrid.appendChild(adCard);
            });
        }

        // Kezdeti renderelés
        renderAds();
    </script>
</body>
</html>