<?php
    session_start();
    if( $_POST['product_name']=="" )  
        die( "<script> alert('Nem adtad meg a termék nevét!') </script>" ) ;

    if( $_POST['description']=="" )  
        die( "<script> alert('Nem adtad meg a termék leírását!') </script>" ) ;

    if( $_POST['price']=="" )  
        die( "<script> alert('Nem adtad meg a termék árát!') </script>" ) ;

    if( $_FILES['image']['name'] == "" )  
        die( "<script> alert('Nem adtad meg a termék képét!') </script>" ) ;

    print_r( $_POST );

    include("kapcsolat.php");

    $tkep = $_FILES['image'];


    if($tkep['name'] != "") {
        
        $imageInfo = getimagesize($tkep['tmp_name']);
        if ($imageInfo === false) {
            die("<script>alert('A fájl nem egy kép!')</script>");
        }

        
        list($width, $height) = $imageInfo;

        
        $minWidth = 0; 
        $maxWidth = 600; 
        $minHeight = 0; 
        $maxHeight = 600;

        
        if ($width < $minWidth || $width > $maxWidth) {
            die("<script>alert('A kép szélessége nem megfelelő! Min. {$minWidth}px, Max. {$maxWidth}px.')</script>");
        } elseif ($height < $minHeight || $height > $maxHeight) {
            die("<script>alert('A kép magassága nem megfelelő! Min. {$minHeight}px, Max. {$maxHeight}px.')</script>");
        }

        
        $ujtkepnev = $_SESSION['uid'] . "_" . date("ymdHis") . "_" . $_POST['product_name'];
        if($tkep['type'] == "image/jpeg") {
            $ujtkepnev .= ".jpg";
        } else if($tkep['type'] == "image/png") {
            $ujtkepnev .= ".png";
        } else {
            die("<script>alert('A kép csak JPG vagy PNG lehet!')</script>");
        }

        
        move_uploaded_file($tkep['tmp_name'], "./termekkepek/" . $ujtkepnev);
    }

    
    mysqli_query($adb, "
        INSERT INTO termekek(tid, tuid, tnev, tleiras, tar, tkep) 
        VALUES (NULL, '$_SESSION[uid]', '$_POST[product_name]', '$_POST[description]', '$_POST[price]', '$ujtkepnev')
    ");

    
    print(
        "<script>
            alert('A terméket sikeresen feltöltötted!')
            parent.location.href='http://localhost/zz/wvp/adokveszek'
        </script>"
    );
?>
