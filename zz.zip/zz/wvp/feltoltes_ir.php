<?php
    session_start();
    if( $_POST['product_name']=="" )  
		die( "<script> alert('Nem adtad meg a termék nevét!') </script>" ) ;

    if( $_POST['description']=="" )  
		die( "<script> alert('Nem adtad meg a termék leírását!') </script>" ) ;

    if( $_POST['price']=="" )  
		die( "<script> alert('Nem adtad meg a termék árát!') </script>" ) ;


    print_r ( $_POST ) ;

    include("kapcsolat.php") ;
    $tkep = $_FILES['image'];

    if($tkep['name'] != ""){
      $ujtkepnev = $_SESSION['uid'] . "_" . date("ymdHis") . "_" . $_POST['product_name'];
      if($tkep['type'] == "image/jpeg")$ujtkepnev .= ".jpg"; else
      if($tkep['type'] == "image/png")$ujtkepnev .= ".png";  else
      die("<script>alert('A kép csak JPG vagy PNG lehet!')</script>");
      move_uploaded_file( $tkep['tmp_name'] , "./termekkepek/" . $ujtkepnev);
    }
    echo "<pre>";
    print_r($_POST);
    echo "</pre>";

    $query = "
    INSERT INTO termekek(tid,            tuid   ,                 tnev   ,           tleiras     ,         tar     ,      tkategoria  ,         tallapot  ,     tkep     ) 
    VALUES (NULL, '{$_SESSION['uid']}', '{$_POST['product_name']}', '{$_POST['description']}', '{$_POST['price']}', '{$_POST['category']}', '{$_POST['condition']}', '$ujtkepnev')
    ";

    if (!mysqli_query($adb, $query)) {
      die("<script>alert('Hiba történt a feltöltés közben: " . mysqli_error($adb) . "')</script>");
    } else {
      print("<script>
          alert('A terméket sikeresen feltöltötted!');
          parent.location.href='http://localhost/zz/wvp/adokveszek'
      </script>");
  }

  mysqli_close( $adb ) ;
?>