<?php
session_start();
$conn = new mysqli("localhost", "root", "", "wv1");

if ($conn->connect_error) {
    die("Kapcsolódási hiba: " . $conn->connect_error);
}

if (isset($_SESSION['uid']) && isset($_POST['productId'])) {
    $userId = $_SESSION['uid'];
    $productId = intval($_POST['productId']); 

    $checkSql = "SELECT * FROM kedvencek WHERE keuid = ? AND ketid = ?";
    $stmt = $conn->prepare($checkSql);
    $stmt->bind_param("ii", $userId, $productId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        $insertSql = "INSERT INTO kedvencek (keid, keuid, ketid) VALUES (NULL, ?, ?)";
        $insertStmt = $conn->prepare($insertSql);
        $insertStmt->bind_param("ii", $userId, $productId);

        if ($insertStmt->execute()) {
            $message = "✅ Sikeresen hozzáadtad a kedvencekhez!";
        } else {
            $message = "❌ Hiba történt a mentés során: " . $insertStmt->error;
        }
        $insertStmt->close();
    } else {
        $message = "ℹ️ A termék már a kedvenceid között van!";
    }
    $stmt->close();
} else {
    $message = "⚠️ Hibás kérés vagy nem vagy bejelentkezve!";
}

$conn->close();
header("Location: adokveszek.php?message=" . urlencode($message));
exit();
?>
