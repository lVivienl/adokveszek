<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Termék részletei</title>
    <link rel="stylesheet" href="marketplace.css">
</head>
<body>
    <div class="container">
        <main class="product-details-container">
            <?php
                $conn = new mysqli("localhost", "root", "", "wv1");
                if ($conn->connect_error) {
                    die("Kapcsolódási hiba: " . $conn->connect_error);
                }

                if (isset($_GET['tid'])) {
                    $tid = $conn->real_escape_string($_GET['tid']);
                    $sql = "SELECT tid, tnev, tar, tleiras, tkep FROM termekek WHERE tid='$tid'";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        $row = $result->fetch_assoc();
                        echo "<div class='product-details'>";
                        echo "<div class='product-image-large'>";
                        echo "<img src='./termekkepek/{$row['tkep']}' alt='{$row['tnev']}'>";
                        echo "</div>";
                        echo "<div class='product-info'>";
                        echo "<h2>{$row['tnev']}</h2>";
                        echo "<p class='price'>{$row['tar']} Ft</p>";
                        echo "<p class='description'>{$row['tleiras']}</p>";
                        echo "<form action='adokveszek_ir.php' target='kisablak' method='POST'>";
                        echo "<input type='hidden' name='productId' value='{$row['tid']}'>";
                        echo "<button type='submit' class='favorite-button'>♥ Kedvencekhez</button>";
                        echo "</form>";
                        echo "<button class='purchase-button'>Vásárlás</button>";
                        echo "</div>";
                        echo "</div>";
                    } else {
                        echo "<p>A keresett termék nem található.</p>";
                    }
                } else {
                    echo "<p>Nem lett megadva termékazonosító.</p>";
                }

                $conn->close();
            ?>
        </main>
    </div>

    <style>
        .product-details-container {
            padding: 2rem;
            margin: 0 auto;
            align-items: center;
            max-width: 1200px;
        }

        .product-details {
            display: flex;
            gap: 2rem;
            background-color: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .product-image-large img {
            width: 400px;
            height: 400px;
            object-fit: cover;
            border-radius: 10px;
        }

        .product-info {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .product-info h2 {
            color: #009B77;
            font-size: 2rem;
            margin-bottom: 1rem;
        }

        .product-info .price {
            color: #000000;
            font-size: 1.5rem;
            margin-bottom: 1rem;
        }

        .product-info .description {
            color: #333333;
            font-size: 1rem;
            line-height: 1.5;
            margin-bottom: 1.5rem;
        }

        .favorite-button, .purchase-button {
            border: none;
            padding: 0.8rem 1.5rem;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s;
        }

        .favorite-button {
            background-color: #009B77;
            color: white;
            margin-bottom: 1rem;
        }

        .favorite-button:hover {
            background-color: #007960;
        }

        .purchase-button {
            background-color: #000000;
            color: white;
        }

        .purchase-button:hover {
            background-color: #333333;
        }
    </style>
</body>
</html>
